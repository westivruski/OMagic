package com.example.omagic

class User(val id: Int =-1, val name: String, val password: String, val email: String)